package Test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTokenizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
