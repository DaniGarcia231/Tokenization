package test.com;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

@RestController
public class TokenizationController {

	
	@PostMapping("private/v1/security/token")
	public HttpEntity<JSONObject> TokenizationReponse(HttpEntity<JSONObject> entity) {
		
		System.out.println("\nServer received from client:" + entity.getBody());
		
		Map<String, String> matchedStrings = new HashMap<>();
		matchedStrings.put("match1", "TokenizedAccount");
		matchedStrings.put("match2", "TokenizeAccount");
		
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("countryCode", "US");
		headers.set("businessCode", "GCB");
		headers.set("channelId", "CBOL");
		
		
		JSONObject request1 = new JSONObject();
		request1.put("tokenizationMap", matchedStrings);
		request1.put("confidentialityLevel", "C");
		
		
		JSONArray generateTokenRequest = new JSONArray();
		generateTokenRequest.add(request1);
		
		JSONObject body = new JSONObject();
		body.put("generateTokenRequest", generateTokenRequest);
		
		
		entity = new HttpEntity<JSONObject>(body, headers);
		
		
		System.out.println("Server is responding to client:" + entity.getBody());
		
		return entity;
	}
}
