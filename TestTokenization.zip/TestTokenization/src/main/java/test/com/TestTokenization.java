package test.com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;


@SpringBootApplication
@SuppressWarnings("rawtypes")
public class TestTokenization {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		SpringApplication.run(TestTokenization.class, args);
		
		ResponseEntity<Map> result;
		
		Pattern p = Pattern.compile("\\b(\\d{12})\\b");
		Matcher m = p.matcher("My account number is 123456789012. Lets us add another 210987654321");
		Map<String, String> matchedStrings = new HashMap<>();
		
		int index = 1;
		
		if(m.find()) {
			boolean morePatternsPresent = false;
			
			do {
				matchedStrings.put("match"+index, m.group());
				morePatternsPresent = m.find();
				index++;
			} while (morePatternsPresent);
		}
		
		result = tokenizeString(matchedStrings);
		
		
		System.out.println("Main received from tokenizeString:" + result.getBody());
		System.out.println("\nStarting tests with server's response:");
		
		
		result.getBody().keySet().forEach(keyStr1 ->
			{
				System.out.println("\nInside 1st ForEach - keyStr1");
				Object keyValue1 = result.getBody().get(keyStr1);
		        System.out.println("key: "+ keyStr1 + " value: " + keyValue1);
		        System.out.println("keyValue1 Class is: " + keyValue1.getClass());
		        
		        if(keyValue1 instanceof ArrayList) {
		        	
		        	System.out.println("\nInside 1st IF - keyValue1 Instance of ArrayList");
		        	
		        	((ArrayList) keyValue1).forEach(keyStr2 ->
		        	{
		        		System.out.println("\nInside 2nd ForEach - keyStr2");
		        		Object keyValue2 = result.getBody().get(keyStr2);
		        		System.out.println("key: "+ keyStr2 + " value: " + keyValue2);
		        		System.out.println("keyStr2 Class is: " + keyStr2.getClass());
		        		System.out.println("keyValue2 is null, no class ");
		        		
		        		 if(keyStr2 instanceof LinkedHashMap) {
		        			 System.out.println("\nInside 2nd IF - keyStr2 Instance of LinkedHashMap");
		        			 
		        			 ((LinkedHashMap) keyStr2).keySet().forEach(keyStr3 ->
		        			 {
		        				System.out.println("\nInside 3th ForEach - keyStr3");
		        				Object keyValue3 = result.getBody().get(keyStr3);
		 		        		System.out.println("key: "+ keyStr3 + " value: " + keyValue3);
		 		        		System.out.println("KeyStr3 = " + keyStr3 + " Class is: " + keyStr3.getClass());
		 		        		System.out.println("KeyStr3 = " + keyStr3 + " Value is null, no class ");
		 		        		
		 		        		
		 		        		//I was planning on retrieving values from tokenizationMap here and then using
		 		        		//Pattern and Matcher to replace values from original string with response values,
		 		        		//but i'm not sure why values in tokenizationMap are null.
		 		        		
		 		        		
		        			 });
		        			 		
		        		 }
		        	});
		        	
				}
		    });	
	}
	
	
	private static ResponseEntity<Map> tokenizeString(Map<String, String> matchedStrings) {
		
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://localhost:8080/private/v1/security/token";
		HttpHeaders headers = new HttpHeaders();
		
		headers.set("countryCode", "US");
		headers.set("businessCode", "GCB");
		headers.set("channelId", "CBOL");
		
		JSONObject body = new JSONObject();
		JSONObject request1 = new JSONObject();
		
		request1.put("tokenizationMap", matchedStrings);
		request1.put("confidentialityLevel", "C");
		
		JSONArray generateTokenRequest = new JSONArray();
		
		generateTokenRequest.add(request1);
		
		body.put("generateTokenRequest", generateTokenRequest);
		
		HttpEntity<JSONObject> httpEntity = new HttpEntity<JSONObject>(body, headers);
		
		ResponseEntity<Map> result = restTemplate.exchange(url, HttpMethod.POST, httpEntity, Map.class);
		result.getBody();
		
		System.out.println("Client received from Server:" + result);
		
		return result;
	}
	
}
